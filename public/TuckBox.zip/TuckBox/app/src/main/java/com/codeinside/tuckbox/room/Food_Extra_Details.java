package com.codeinside.tuckbox.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity
public class Food_Extra_Details implements Serializable {

    public int getFood_Details_ID() {
        return Food_Details_ID;
    }

    public void setFood_Details_ID(int food_Details_ID) {
        Food_Details_ID = food_Details_ID;
    }

    public String getDetailsName() {
        return detailsName;
    }

    public void setDetailsName(String detailsName) {
        this.detailsName = detailsName;
    }

    public String getFoodFood_ID() {
        return FoodFood_ID;
    }

    public void setFoodFood_ID(String foodFood_ID) {
        FoodFood_ID = foodFood_ID;
    }

    @PrimaryKey(autoGenerate = true)
    private int Food_Details_ID;

    @ColumnInfo(name = "Details_Name")
    private String detailsName;

    @ColumnInfo(name = "FoodFood_ID")
    private String FoodFood_ID;

}
