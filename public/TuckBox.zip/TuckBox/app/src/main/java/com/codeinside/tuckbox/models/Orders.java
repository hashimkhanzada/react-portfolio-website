package com.codeinside.tuckbox.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Orders implements Serializable {

    public Orders(String id, String region, String address, ArrayList<MealOption> meals, String note, String slot) {
        this.id = id;
        this.region = region;
        this.address = address;
        this.meals = meals;
        this.note = note;
        this.slot = slot;
    }

    private String id;
    private String region;
    private String address;
    private ArrayList<MealOption> meals;
    private String note;
    private String slot;


    public Orders(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<MealOption> getMeals() {
        return meals;
    }

    public void setMeals(ArrayList<MealOption> meals) {
        this.meals = meals;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }




}
