package com.codeinside.tuckbox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.codeinside.tuckbox.models.MealOption;
import com.codeinside.tuckbox.models.Orders;
import com.codeinside.tuckbox.room.Users;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class PlaceOrderActivity extends AppCompatActivity {

    AutoCompleteTextView region, slots;
    TextView sigup, title;
    AppCompatImageView back;
    Button buttonPlaceOrder;
    TextInputEditText addreess, order_note;
    CheckBox checkboxsalad, checkboxKorma, checkboxSandwich, checkboxNoodles;

    RadioButton none, ranch, Vinaigrette, mild, med, hot, white, rye, wholmeal, none_chili, extraChili, regChili;

    EditText quantitySalad, quantityqorma, quantitysandwich, quantitynodles;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);
        getSupportActionBar().hide();
        back = (AppCompatImageView) findViewById(R.id.action_back);
        title = (TextView) findViewById(R.id.toolbar_create_title);
        buttonPlaceOrder = (Button) findViewById(R.id.buttonPlaceOrder);


        addreess = (TextInputEditText) findViewById(R.id.aaddres);
        order_note = (TextInputEditText) findViewById(R.id.order_note);

        checkboxsalad = (CheckBox) findViewById(R.id.checkboxsalad);
        checkboxKorma = (CheckBox) findViewById(R.id.checkboxKorma);
        checkboxSandwich = (CheckBox) findViewById(R.id.checkboxSandwich);
        checkboxNoodles = (CheckBox) findViewById(R.id.checkboxNoodles);

        none = (RadioButton) findViewById(R.id.none);
        ranch = (RadioButton) findViewById(R.id.ranch);
        Vinaigrette = (RadioButton) findViewById(R.id.vinaigrette);
        mild = (RadioButton) findViewById(R.id.mild);

        med = (RadioButton) findViewById(R.id.med);
        hot = (RadioButton) findViewById(R.id.hot);
        white = (RadioButton) findViewById(R.id.white);
        rye = (RadioButton) findViewById(R.id.rye);

        wholmeal = (RadioButton) findViewById(R.id.wholmeal);
        none_chili = (RadioButton) findViewById(R.id.none_chili);
        extraChili = (RadioButton) findViewById(R.id.extraChili);
        regChili = (RadioButton) findViewById(R.id.regChili);

        quantitySalad = (EditText) findViewById(R.id.quantitySalad);
        quantityqorma = (EditText) findViewById(R.id.quantityqorma);
        quantitysandwich = (EditText) findViewById(R.id.quantitysandwich);
        quantitynodles = (EditText) findViewById(R.id.quantitynodles);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        title.setText("Place Order");

        String[] COUNTRIES = new String[]{"Palmerston North", "Feilding", "Ashhurst", "Longburn"};
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(
                        PlaceOrderActivity.this,
                        R.layout.dropdown_menu_popup_item,
                        COUNTRIES);
        region = findViewById(R.id.filled_region);
        region.setAdapter(adapter);
        region.setSelection(0);


        String[] slots_arr = new String[]{"11:45-12:15", "12:15-12:45", "12:45-13:15", "13:15-13:45"};
        ArrayAdapter<String> adapterSlots =
                new ArrayAdapter<String>(
                        PlaceOrderActivity.this,
                        R.layout.dropdown_menu_popup_item,
                        slots_arr);
        slots = findViewById(R.id.filled_slots);
        slots.setAdapter(adapterSlots);
        slots.setSelection(0);

        buttonPlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addOrder();
            }
        });

    }

    private void addOrder() {

        if (region.getText().toString().equals("") || region.getText().toString().equals("Select Region")) {
            Toast.makeText(PlaceOrderActivity.this, "Select Region", Toast.LENGTH_SHORT).show();
        } else if (addreess.getText().toString().equals("")) {
            Toast.makeText(PlaceOrderActivity.this, "Add Address", Toast.LENGTH_SHORT).show();
        } else if (!checkboxsalad.isChecked() && !checkboxKorma.isChecked() && !checkboxSandwich.isChecked() && !checkboxNoodles.isChecked()) {
            Toast.makeText(PlaceOrderActivity.this, "Select at least one meal option", Toast.LENGTH_SHORT).show();
        } else if (checkboxsalad.isChecked() && quantitySalad.getText().toString().length() == 0) {
            Toast.makeText(PlaceOrderActivity.this, "Add Green Salad Lunch Quantity", Toast.LENGTH_SHORT).show();
        } else if (checkboxKorma.isChecked() && quantityqorma.getText().toString().length() == 0) {
            Toast.makeText(PlaceOrderActivity.this, "Add Lamb Korma Quantity", Toast.LENGTH_SHORT).show();
        } else if (checkboxSandwich.isChecked() && quantitysandwich.getText().toString().length() == 0) {
            Toast.makeText(PlaceOrderActivity.this, "Add Open Chicken Sandwich Quantity", Toast.LENGTH_SHORT).show();
        } else if (checkboxNoodles.isChecked() && quantitynodles.getText().toString().length() == 0) {
            Toast.makeText(PlaceOrderActivity.this, "Add Beef Noodle Salad Quantity", Toast.LENGTH_SHORT).show();
        } else if (slots.getText().toString().equals("") || region.getText().toString().equals("Delivery Time")) {
            Toast.makeText(PlaceOrderActivity.this, "Delivery Time", Toast.LENGTH_SHORT).show();
        } else {
            ArrayList<MealOption> list = new ArrayList<>();
            if (checkboxsalad.isChecked()) {
                String option = "";
                if (none.isChecked()) {
                    option = "none";
                } else if (ranch.isChecked()) {
                    option = "ranch";
                } else if (Vinaigrette.isChecked()) {
                    option = "Vinaigrette";
                }
                MealOption mealOption = new MealOption(checkboxsalad.getText().toString(), option, quantitySalad.getText().toString());
                list.add(mealOption);
            }  if (checkboxKorma.isChecked()) {
                String option = "";
                if (mild.isChecked()) {
                    option = "mild";
                } else if (med.isChecked()) {
                    option = "med";
                } else if (hot.isChecked()) {
                    option = "hot";
                }
                MealOption mealOption = new MealOption(checkboxKorma.getText().toString(), option, quantityqorma.getText().toString());
                list.add(mealOption);

            }  if (checkboxSandwich.isChecked()) {
                String option = "";
                if (mild.isChecked()) {
                    option = "mild";
                } else if (med.isChecked()) {
                    option = "med";
                } else if (hot.isChecked()) {
                    option = "hot";
                }
                MealOption mealOption = new MealOption(checkboxSandwich.getText().toString(), option, quantitysandwich.getText().toString());
                list.add(mealOption);

            }  if (checkboxNoodles.isChecked()) {
                String option = "";
                if (none_chili.isChecked()) {
                    option = "no chili flakes";
                } else if (regChili.isChecked()) {
                    option = "regular chili flakes";
                } else if (extraChili.isChecked()) {
                    option = "extra chili flakes";
                }
                MealOption mealOption = new MealOption(checkboxNoodles.getText().toString(), option, quantitynodles.getText().toString());
                list.add(mealOption);

            }

            Orders orders = new Orders(
                    "",
                    region.getText().toString(),
                    addreess.getText().toString(),
                    list,
                    order_note.getText().toString(),
                    slots.getText().toString());


            db.collection("orders")
                    .add(orders)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Toast.makeText(PlaceOrderActivity.this, "Order created", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(PlaceOrderActivity.this, "Error while creating Order", Toast.LENGTH_SHORT).show();
                        }
                    });

        }

    }

    public void onRadioClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.none:
                none.setChecked(true);
                ranch.setChecked(false);
                Vinaigrette.setChecked(false);
                break;

            case R.id.ranch:
                none.setChecked(false);
                ranch.setChecked(true);
                Vinaigrette.setChecked(false);
                break;

            case R.id.vinaigrette:
                none.setChecked(false);
                ranch.setChecked(false);
                Vinaigrette.setChecked(true);
                break;

            case R.id.mild:
                mild.setChecked(true);
                med.setChecked(false);
                hot.setChecked(false);
                break;

            case R.id.med:
                mild.setChecked(false);
                med.setChecked(true);
                Vinaigrette.setChecked(false);
                break;


            case R.id.hot:
                mild.setChecked(false);
                med.setChecked(false);
                hot.setChecked(true);
                break;

            case R.id.white:
                white.setChecked(true);
                rye.setChecked(false);
                wholmeal.setChecked(false);
                break;

            case R.id.rye:
                white.setChecked(false);
                rye.setChecked(true);
                wholmeal.setChecked(false);
                break;


            case R.id.wholmeal:
                white.setChecked(false);
                rye.setChecked(false);
                wholmeal.setChecked(true);
                break;


            case R.id.none_chili:
                none_chili.setChecked(true);
                regChili.setChecked(false);
                extraChili.setChecked(false);
                break;

            case R.id.regChili:
                none_chili.setChecked(false);
                regChili.setChecked(true);
                extraChili.setChecked(false);
                break;


            case R.id.extraChili:
                none_chili.setChecked(false);
                regChili.setChecked(false);
                extraChili.setChecked(true);
                break;

        }


    }
}