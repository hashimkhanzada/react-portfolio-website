package com.codeinside.tuckbox.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity
public class Orders implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int Order_ID;

    @ColumnInfo(name = "Order_Date")
    private String orderDate;

    @ColumnInfo(name = "Quantity")
    private String quantity;

    @ColumnInfo(name = "Food_Extra_DetailsFood_Details_ID")
    private String foodExtraDetailsFoodDetailsID;

    @ColumnInfo(name = "TimeSlotsTime_Slot_ID")
    private String timeSlotsTimeSlotID;

    @ColumnInfo(name = "UserUser_ID")
    private String userUserID;


    public int getOrder_ID() {
        return Order_ID;
    }

    public void setOrder_ID(int order_ID) {
        Order_ID = order_ID;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getFoodExtraDetailsFoodDetailsID() {
        return foodExtraDetailsFoodDetailsID;
    }

    public void setFoodExtraDetailsFoodDetailsID(String foodExtraDetailsFoodDetailsID) {
        this.foodExtraDetailsFoodDetailsID = foodExtraDetailsFoodDetailsID;
    }

    public String getTimeSlotsTimeSlotID() {
        return timeSlotsTimeSlotID;
    }

    public void setTimeSlotsTimeSlotID(String timeSlotsTimeSlotID) {
        this.timeSlotsTimeSlotID = timeSlotsTimeSlotID;
    }

    public String getUserUserID() {
        return userUserID;
    }

    public void setUserUserID(String userUserID) {
        this.userUserID = userUserID;
    }


}
