package com.codeinside.tuckbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.codeinside.tuckbox.room.Users;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.auth.User;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    TextView sigup,title;
    AppCompatImageView back;
    TextInputEditText email, password;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ProgressBar progressBar;
    Button login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        sigup = (TextView)findViewById(R.id.sign_up);
        login = (Button)findViewById(R.id.signIn);
        progressBar = (ProgressBar) findViewById(R.id.progress_circular);

        email = (TextInputEditText) findViewById(R.id.edittextEmail);
        password = (TextInputEditText) findViewById(R.id.passwordEditTextLogin);


        sigup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,SignupActivity.class));
            }
        });

        back = (AppCompatImageView)findViewById(R.id.action_back);
        title = (TextView)findViewById(R.id.toolbar_create_title);
        title.setText(getString(R.string.sign_in));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onLoginClicked();
            }
        });

    }

    private void onLoginClicked(){

        if (email.getText().toString().length() == 0 ||
                password.getText().toString().length() == 0
              ) {

            Toast.makeText(this, "Enter all the details", Toast.LENGTH_SHORT).show();

        } else {
            //Users city = queryDocumentSnapshots.toObject(Users.class);
            progressBar.setVisibility(View.VISIBLE);
            db.collection("users").
                    whereEqualTo("email",email.getText().toString())
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot documentSnapshot) {
                            List<Users> list = documentSnapshot.toObjects(Users.class);
                            if (list!=null && list.size()>0){
                                if (list.get(0).getPassword().equals(password.getText().toString())){
                                    Utils.currentUser = list.get(0);
                                    Toast.makeText(LoginActivity.this, "Login successfully", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(LoginActivity.this,DashboardActivity.class));
                                    finish();
                                } else {
                                    Toast.makeText(LoginActivity.this, "No User found", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(LoginActivity.this, "No User found", Toast.LENGTH_SHORT).show();
                            }
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }

    }
}