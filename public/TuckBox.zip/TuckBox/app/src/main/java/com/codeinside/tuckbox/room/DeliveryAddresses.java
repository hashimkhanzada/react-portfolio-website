package com.codeinside.tuckbox.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class DeliveryAddresses implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int Address_ID;

    public int getAddress_ID() {
        return Address_ID;
    }

    public void setAddress_ID(int address_ID) {
        Address_ID = address_ID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUsersUser_ID() {
        return UsersUser_ID;
    }

    public void setUsersUser_ID(String usersUser_ID) {
        UsersUser_ID = usersUser_ID;
    }

    @ColumnInfo(name = "Address")
    private String address;

    @ColumnInfo(name = "UsersUser_ID")
    private String UsersUser_ID;
}
