package com.codeinside.tuckbox.models;

import java.io.Serializable;

public class MealOption implements Serializable {

    private String mealName;
    private String mealOption;
    private String quantity;

    public MealOption(String mealName, String mealOption, String quantity) {
        this.mealName = mealName;
        this.mealOption = mealOption;
        this.quantity = quantity;
    }

    public MealOption(){

    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    public String getMealName() {
        return mealName;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }

    public String getMealOption() {
        return mealOption;
    }

    public void setMealOption(String mealOption) {
        this.mealOption = mealOption;
    }


}
