package com.codeinside.tuckbox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.codeinside.tuckbox.room.Users;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileActivity extends AppCompatActivity {

    TextView sigup, title;
    AppCompatImageView back;
    Button buttonSignup;

    TextInputEditText firstName, lastName, email, password, phone,address;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        getSupportActionBar().hide();

        back = (AppCompatImageView) findViewById(R.id.action_back);
        title = (TextView) findViewById(R.id.toolbar_create_title);
        progressBar = (ProgressBar) findViewById(R.id.progress_circular);

        firstName = (TextInputEditText) findViewById(R.id.name);
        lastName = (TextInputEditText) findViewById(R.id.user_name);
        email = (TextInputEditText) findViewById(R.id.edittextEmail);
        password = (TextInputEditText) findViewById(R.id.passwordEditText);
        phone = (TextInputEditText) findViewById(R.id.phoneEditText);
        address = (TextInputEditText) findViewById(R.id.addressEditText);

        buttonSignup = (Button) findViewById(R.id.buttonSignup);
        title.setText("Update Profile");

        if (Utils.currentUser!=null){
            firstName.setText(Utils.currentUser.getFirstName());
            lastName.setText(Utils.currentUser.getLastName());
            email.setText(Utils.currentUser.getEmail());
            password.setText(Utils.currentUser.getPassword());
            phone.setText(Utils.currentUser.getMobile());
            address.setText(Utils.currentUser.getAddress());
        }


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        buttonSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onUpdateClicked();
            }
        });
    }

    private void onUpdateClicked(){

        if (firstName.getText().toString().length() == 0 ||
                lastName.getText().toString().length() == 0 ||
                email.getText().toString().length() == 0 ||
                password.getText().toString().length() == 0 ||
                phone.getText().toString().length() == 0 ||
                address.getText().toString().length() == 0) {

            Toast.makeText(this, "Enter all the details", Toast.LENGTH_SHORT).show();

        } else {
            Users users = new Users(
                    email.getText().toString(),
                    password.getText().toString(),
                    firstName.getText().toString(),
                    lastName.getText().toString(),
                    phone.getText().toString(),"");

            users.setAddress(address.getText().toString());
            users.setFirebaseID(Utils.currentUser.getFirebaseID());
            Utils.currentUser = users;
            db.collection("users").document(Utils.currentUser.getFirebaseID()).set(users);
            Toast.makeText(ProfileActivity.this, "User Updated successfully", Toast.LENGTH_SHORT).show();


        }
    }
}