package com.codeinside.tuckbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.codeinside.tuckbox.models.Orders;
import com.codeinside.tuckbox.room.Users;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private OrderAdapter mAdapter;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ProgressBar progressBar;
    TextView sigup,title;
    AppCompatImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);
        getSupportActionBar().hide();

        back = (AppCompatImageView)findViewById(R.id.action_back);
        title = (TextView)findViewById(R.id.toolbar_create_title);
        title.setText("Orders");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        recyclerView = (RecyclerView) findViewById(R.id.orders);
        progressBar = (ProgressBar) findViewById(R.id.progress_circular);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // specify an adapter (see also next example)
        mAdapter = new OrderAdapter(OrderHistoryActivity.this, new ArrayList<>());
        recyclerView.setAdapter(mAdapter);
        getData();
    }

    private void getData() {
        progressBar.setVisibility(View.VISIBLE);
        db.collection("orders")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot documentSnapshot) {
                        List<Orders> list = documentSnapshot.toObjects(Orders.class);
                        if (list != null && list.size() > 0) {
                            mAdapter.updateOrders(list);
                        } else {
                            Toast.makeText(OrderHistoryActivity.this, "No orders found", Toast.LENGTH_SHORT).show();
                        }
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }
}