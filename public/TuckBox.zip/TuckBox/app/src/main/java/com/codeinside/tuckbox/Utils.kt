package com.codeinside.tuckbox

import android.content.Context
import android.content.Context.MODE_PRIVATE
import com.codeinside.tuckbox.room.Users
import com.google.gson.Gson


object Utils {

    const val GRADEOUT_SUBJECT_KEY = "GRADEOUT_SUBJECT_KEY"
    const val SUBJECT_KEY = "SUBJECT_KEY"
    const val CHAPTER_KEY = "CHAPTER_KEY"
    const val SET_KEY = "SET_KEY"
    const val QUESTION_KEY = "QUESTION_KEY"


    @JvmField
    var currentUser: Users? = null
    const val keyUserObject: String = "keyUserObject"
    const val keyIsUserLogin: String = "keyIsUserLogin"

    fun saveDataInPreference(context: Context, key: String, value: String) {
        val sharedPreferences = context.getSharedPreferences("MySharedPref", MODE_PRIVATE)
        val myEdit = sharedPreferences.edit()
        myEdit.putString(key, value)
        myEdit.apply()
    }

    fun getDataInPreference(context: Context, key: String): String {
        val sharedPreferences = context.getSharedPreferences("MySharedPref", MODE_PRIVATE)
        return sharedPreferences.getString(key, "").toString()
    }

    fun saveUserObject(context: Context, key: String, user: Users?) {
        val sharedPreferences = context.getSharedPreferences("MySharedPref", MODE_PRIVATE)
        val myEdit = sharedPreferences.edit()
        val gson = Gson()
        val jsonUser = gson.toJson(user)
        myEdit.putString(key, jsonUser)
        myEdit.apply()
    }

    fun getUserObject(context: Context, key: String): Users? {
        val sharedPreferences = context.getSharedPreferences("MySharedPref", MODE_PRIVATE)
        var userString = sharedPreferences.getString(key, "").toString()
        val gson = Gson()
        var user: Users = gson.fromJson(userString, Users::class.java)
        return user
    }

}




