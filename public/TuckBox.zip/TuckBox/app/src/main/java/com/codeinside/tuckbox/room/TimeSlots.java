package com.codeinside.tuckbox.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity
public class TimeSlots implements Serializable {

    public int getTime_Slots_ID() {
        return Time_Slots_ID;
    }

    public void setTime_Slots_ID(int time_Slots_ID) {
        Time_Slots_ID = time_Slots_ID;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }

    @PrimaryKey(autoGenerate = true)
    private int Time_Slots_ID;

    @ColumnInfo(name = "Time_Slot")
    private String timeSlot;

}
