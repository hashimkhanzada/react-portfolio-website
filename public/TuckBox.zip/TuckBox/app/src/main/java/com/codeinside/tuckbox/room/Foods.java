package com.codeinside.tuckbox.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity
public class Foods implements Serializable {

    public int getFood_ID() {
        return Food_ID;
    }

    public void setFood_ID(int food_ID) {
        Food_ID = food_ID;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodExtraChoice() {
        return foodExtraChoice;
    }

    public void setFoodExtraChoice(String foodExtraChoice) {
        this.foodExtraChoice = foodExtraChoice;
    }

    @PrimaryKey(autoGenerate = true)
    private int Food_ID;

    @ColumnInfo(name = "Food_Name")
    private String foodName;

    @ColumnInfo(name = "Food_Extra_Choice")
    private String foodExtraChoice;
}
