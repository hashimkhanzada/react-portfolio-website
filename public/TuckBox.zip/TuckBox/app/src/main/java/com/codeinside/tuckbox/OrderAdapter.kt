package com.codeinside.tuckbox

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.codeinside.tuckbox.models.Orders

class OrderAdapter(
    val context: Context,
    private var orders: List<Orders>
) : RecyclerView.Adapter<OrderAdapter.OrdersViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrdersViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.layout_order, parent, false)
        return OrdersViewHolder(view)
    }

    override fun getItemCount(): Int = orders.size

    override fun onBindViewHolder(holder: OrdersViewHolder, position: Int) {
        holder.bind(orders[position])
    }

    fun updateOrders(list: List<Orders>) {
        this.orders = list
        notifyDataSetChanged()
    }

    inner class OrdersViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val slot: AppCompatTextView = itemView.findViewById(R.id.slot)
        private val region: AppCompatTextView = itemView.findViewById(R.id.region)
        private val address: AppCompatTextView = itemView.findViewById(R.id.address)
        private val meals: AppCompatTextView = itemView.findViewById(R.id.meals)



        fun bind(order: Orders) {
            slot.text = "Delivery Time "+order.slot
            region.text = "Regiion " + order.region
            address.text = "Address "+order.address
            var meal = ""
            if (order.meals!=null) {
                for (i in 0 until order.meals.size) {
                    meal += order.meals.get(i).mealName + " " + order.meals.get(i).quantity + "\n"
                }
            }
            meals.text = meal

        }
    }
}
