package com.codeinside.tuckbox.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity
public class Cities implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int City_ID;

    @ColumnInfo(name = "CityName")
    private String cityName;

    public int getCity_ID() {
        return City_ID;
    }

    public void setCity_ID(int city_ID) {
        City_ID = city_ID;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

}
