package com.codeinside.tuckbox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.codeinside.tuckbox.room.Users;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignupActivity extends AppCompatActivity {

    TextView sigup, title;
    AppCompatImageView back;
    Button buttonSignup;

    TextInputEditText firstName, lastName, email, password, phone;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();

        back = (AppCompatImageView) findViewById(R.id.action_back);
        title = (TextView) findViewById(R.id.toolbar_create_title);
        progressBar = (ProgressBar) findViewById(R.id.progress_circular);

        firstName = (TextInputEditText) findViewById(R.id.name);
        lastName = (TextInputEditText) findViewById(R.id.user_name);
        email = (TextInputEditText) findViewById(R.id.edittextEmail);
        password = (TextInputEditText) findViewById(R.id.passwordEditText);
        phone = (TextInputEditText) findViewById(R.id.phoneEditText);

        buttonSignup = (Button) findViewById(R.id.buttonSignup);
        title.setText(getString(R.string.sign_up));


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        buttonSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSignupClicked();
            }
        });

    }

    private void onSignupClicked() {
        if (firstName.getText().toString().length() == 0 ||
                lastName.getText().toString().length() == 0 ||
                email.getText().toString().length() == 0 ||
                password.getText().toString().length() == 0 ||
                phone.getText().toString().length() == 0) {

            Toast.makeText(this, "Enter all the details", Toast.LENGTH_SHORT).show();

        } else {
            progressBar.setVisibility(View.VISIBLE);

            DocumentReference reference = db.collection("users").document();


            Users users = new Users(
                    email.getText().toString(),
                    password.getText().toString(),
                    firstName.getText().toString(),
                    lastName.getText().toString(),
                    phone.getText().toString(),"");
            users.setFirebaseID(reference.getId());

            db.collection("users")
                    .add(users)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Utils.currentUser = users;
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(SignupActivity.this, "User Created", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(SignupActivity.this,DashboardActivity.class));
                            finish();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(SignupActivity.this, "Error while creating User", Toast.LENGTH_SHORT).show();
                        }
                    });

        }
    }
}